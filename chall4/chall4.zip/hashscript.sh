#!/bin/bash
oldHash=$(echo -n "$1" | sha256sum)
newHash=$(echo -n "$1 " | sha256sum)
echo "$oldHash" > digest.txt
substring="${newHash:0:20}"
echo "kludgeCTF{the_flag_$substring}"

