#!/bin/bash
oldHash=$(echo -n "$1" | sha256sum)
newHash=$(echo -n "$1 " | sha256sum)
echo "$oldHash" > digest.txt

if [[ ${newHash:20:20} == "f1cbf7f7e35e34a5f4ab" ]];    # allowing only correct hash through
then
    flagname="kludgeCTF"
    echo "$flagname{the_flag_${newHash:0:20}}"
fi