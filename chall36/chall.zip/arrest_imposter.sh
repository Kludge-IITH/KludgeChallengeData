#!/bin/bash

# Just enter the name of the imposter and let the police handle the rest
str=$1

# lengthy calculations to delay you from bruteforcing ;)
echo "Calling the Police..."
for ((i = 1; i <= 500; i++)); do
    str=$(echo -n "$str" | sha256sum)
done

flag="kludgeCTF{caseSolved${str:0:15}}" 

echo "Checking the Evidence..."
for ((i = 1; i <= 500; i++)); do
    str=$(echo -n "$str" | sha256sum)
done

if [ "$str" == "5d26438d7af7f6dcd5d5ccfcdc52736af40f24d40d88329a372dd2ab2a289d5e  -" ]; then
    echo "Imposter arrested! Here's your reward: $flag"
else
    echo "The person was not the imposter!"
fi
